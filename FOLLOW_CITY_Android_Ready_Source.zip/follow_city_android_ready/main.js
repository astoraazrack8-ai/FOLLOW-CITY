import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const $=id=>document.getElementById(id);const scene=new THREE.Scene();scene.background=new THREE.Color(0x9bc9d8);scene.fog=new THREE.Fog(0x9bc9d8,65,150);
const camera=new THREE.PerspectiveCamera(48,innerWidth/innerHeight,.1,300);camera.position.set(25,27,30);
const renderer=new THREE.WebGLRenderer({antialias:!(/Android|iPhone|iPad/i.test(navigator.userAgent)),powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;$('game').appendChild(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.07;controls.maxPolarAngle=Math.PI*.48;controls.minDistance=9;controls.maxDistance=85;controls.target.set(0,0,0);
scene.add(new THREE.HemisphereLight(0xffffff,0x627b55,2));const sun=new THREE.DirectionalLight(0xfff1d5,2.2);sun.position.set(-25,40,20);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);scene.add(sun);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(100,100),new THREE.MeshStandardMaterial({color:0x79ad67}));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
const grid=new THREE.GridHelper(80,40,0x638b58,0x8db87d);grid.position.y=.015;scene.add(grid);
function road(x,z,w=5,d=5){let m=new THREE.Mesh(new THREE.BoxGeometry(w,.12,d),new THREE.MeshStandardMaterial({color:0x454b53,roughness:1}));m.position.set(x,.07,z);m.receiveShadow=true;scene.add(m);if(w>d){for(let a=-w/2+1;a<w/2-1;a+=2.4){let l=new THREE.Mesh(new THREE.BoxGeometry(1.1,.025,.12),new THREE.MeshBasicMaterial({color:0xf4e6a0}));l.position.set(x+a,.14,z);scene.add(l)}}return m}
for(let i=-35;i<=35;i+=20){road(i,0,5,75);road(0,i,75,5)}
const loader=new GLTFLoader(),raycaster=new THREE.Raycaster(),mouse=new THREE.Vector2();let catalog=[],selected=null,mode='build',money=5000,people=120,followers=120,likes=45,placed=[],roadMeshes=[],preview=null;
const SAVE_KEY='followcity-v2';
let day=1;
function saveGame(show=true){
  const data={version:2,money,people,followers,likes,day,
    buildings:placed.map(o=>({model:o.userData.model,x:o.position.x,z:o.position.z})),
    roads:roadMeshes.map(o=>({x:o.position.x,z:o.position.z,w:o.geometry.parameters.width,d:o.geometry.parameters.depth}))};
  try{localStorage.setItem(SAVE_KEY,JSON.stringify(data));if(show)toast('تم حفظ مدينتك بنجاح')}
  catch(e){toast('تعذر الحفظ على هذا الجهاز')}
}
const categories=[['houses','🏠 البيوت'],['services','🏥 الخدمات'],['shops','🏪 المتاجر'],['parks','🌳 الحدائق'],['vehicles','🚗 السيارات']];
fetch('./catalog.json').then(r=>r.json()).then(data=>{catalog=data;renderTabs();renderItems();restoreGame()}).catch(()=>toast('تعذر تحميل قائمة المباني'));
let category='houses';function renderTabs(){$('tabs').innerHTML=categories.map(c=>`<button class="tab ${c[0]===category?'active':''}" data-cat="${c[0]}">${c[1]}</button>`).join('');document.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{category=b.dataset.cat;selected=null;renderTabs();renderItems()})}
function renderItems(){let list=catalog.filter(x=>x[0]===category);$('items').innerHTML=list.map(x=>`<button class="item" data-model="${x[2]}">${x[1]}<small>💰 ${x[3]||'مجاني'}</small></button>`).join('');document.querySelectorAll('[data-model]').forEach(b=>b.onclick=()=>{selected=catalog.find(x=>x[2]===b.dataset.model);setMode('build');toast('اختر مكاناً مناسباً على الأرض')})}
function toast(s){let t=$('toast');t.textContent=s;t.style.display='block';clearTimeout(window.tt);window.tt=setTimeout(()=>t.style.display='none',1900)}
function setMode(m){mode=m;['buildMode','roadMode','bulldozeMode','socialMode'].forEach(id=>$(id).classList.remove('active'));({build:'buildMode',road:'roadMode',bulldoze:'bulldozeMode',social:'socialMode'})[m]&&$(({build:'buildMode',road:'roadMode',bulldoze:'bulldozeMode',social:'socialMode'})[m]).classList.add('active')}
$('buildMode').onclick=()=>setMode('build');$('roadMode').onclick=()=>{setMode('road');selected=null;toast('اضغط نقطتين على الأرض لرسم طريق')};$('bulldozeMode').onclick=()=>setMode('bulldoze');$('socialMode').onclick=()=>{setMode('social');toast('تابع نمو مجتمع مدينتك')};
function groundPoint(e){const r=renderer.domElement.getBoundingClientRect();mouse.x=((e.clientX-r.left)/r.width)*2-1;mouse.y=-((e.clientY-r.top)/r.height)*2+1;raycaster.setFromCamera(mouse,camera);let hit=raycaster.intersectObject(ground);return hit[0]?.point}
let roadStart=null;
renderer.domElement.addEventListener('pointerdown',e=>{if(e.button!==0)return;const p=groundPoint(e);if(!p)return;if(mode==='road'){if(!roadStart){roadStart=p;toast('الآن اختر نقطة نهاية الطريق')}else{let mid=roadStart.clone().add(p).multiplyScalar(.5),delta=p.clone().sub(roadStart);let m=road(mid.x,mid.z,Math.max(3,Math.abs(delta.x)),Math.max(3,Math.abs(delta.z)));roadMeshes.push(m);money-=Math.round(delta.length()*2);updateStats();roadStart=null;saveGame(false);toast('تم إنشاء الطريق')}}else if(mode==='build'&&selected){let price=selected[3]||0;if(money<price){toast('لا يوجد رصيد كافٍ');return}placeModel(selected,p.x,p.z);money-=price;updateStats()}else if(mode==='bulldoze'){const obj=placed.find(o=>Math.hypot(o.position.x-p.x,o.position.z-p.z)<3);if(obj){scene.remove(obj);placed=placed.filter(o=>o!==obj);money+=50;updateStats();saveGame(false);toast('تم هدم المبنى')}}});
function placeModel(item,x,z,save=true){let filename=item[2];loader.load('./assets/'+filename,g=>{let obj=g.scene;obj.position.set(Math.round(x/2)*2,0,Math.round(z/2)*2);obj.userData.model=filename;obj.traverse(n=>{if(n.isMesh){n.castShadow=true;n.receiveShadow=true}});let box=new THREE.Box3().setFromObject(obj),size=box.getSize(new THREE.Vector3());let max=Math.max(size.x,size.y,size.z);if(max>0)obj.scale.setScalar(5/max);scene.add(obj);placed.push(obj);if(save){saveGame(false);toast('تم بناء '+item[1])}},undefined,()=>toast('تعذر تحميل هذا النموذج'))}
function updateStats(){$('money').textContent=Math.max(0,money).toLocaleString('en');$('people').textContent=people.toLocaleString('en');$('followers').textContent=followers.toLocaleString('en');$('likes').textContent=likes.toLocaleString('en')}
$('newComment').onclick=()=>{let arr=['نريد حديقة جديدة!','نحتاج متجر قريب من الحي.','المدينة تكبر بسرعة!','نرجو إضافة مدرسة.','شكراً على تطوير المدينة!'];let d=document.createElement('div');d.className='comment';d.textContent='💬 '+arr[Math.floor(Math.random()*arr.length)];$('comments').prepend(d);followers+=3;people+=3;likes+=Math.floor(Math.random()*5)+1;updateStats()};
function restoreGame(){
  let d;try{d=JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch(e){d=null}
  if(!d){toast('ابدأ ببناء مدينتك!');return}
  money=d.money??5000;people=d.people??120;followers=d.followers??120;likes=d.likes??45;day=d.day??1;
  $('day').textContent=day;updateStats();
  (d.roads||[]).forEach(r=>{let m=road(r.x,r.z,r.w||5,r.d||5);roadMeshes.push(m)});
  (d.buildings||[]).forEach(b=>{let item=catalog.find(x=>x[2]===b.model);if(item)placeModel(item,b.x,b.z,false)});
  toast('تم تحميل مدينتك');
}
$('saveBtn').onclick=()=>saveGame(true);
$('loadBtn').onclick=restoreGame;
setInterval(()=>{day++;$('day').textContent=day;if(placed.length){money+=Math.min(placed.length*2,30);updateStats()}saveGame(false)},60000);
addEventListener('pagehide',()=>saveGame(false));

addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.6))});
function animate(){requestAnimationFrame(animate);controls.update();renderer.render(scene,camera)}animate();updateStats();
